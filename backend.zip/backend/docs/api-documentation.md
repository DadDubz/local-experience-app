# Local Experience API Documentation

## Base URL

`https://api.localexperience.app/v1`

## Authentication

All API requests require authentication using a Bearer token:

```http
Authorization: Bearer YOUR_API_TOKEN
```
